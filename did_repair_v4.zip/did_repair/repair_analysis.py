"""Auditable repair and cohort-specific continuous-exposure DID.

Run: python repair_analysis.py --input clean/merged_annual_with_carbon.csv --out result_v4
Never overwrites inputs. Real-data results are generated only when data are supplied.
"""
from pathlib import Path
import argparse
import hashlib
import json
import warnings
import numpy as np
import pandas as pd

KEY = ['stock_code', 'year']
FLAGS = ['is_st', 'is_new_suspend', 'is_bse']
OUTCOMES = ['Nbs_raw', 'Nbs_dminus', 'negative', 'neutral', 'positive', 'pred_class', 'pred_Nbs']
CONTROLS = ['ln_total_assets', 'leverage', 'roa', 'cashflow', 'tobin_q', 'rd_ratio', 'fixed_assets']
# Working regional trading-start calendar, not a list of covered firms.
# Sichuan is not assigned a local pilot treatment. National ETS is a separate policy.
START = {'110000': 2013, '120000': 2013, '310000': 2013, '440000': 2013,
         '420000': 2014, '500000': 2014, '350000': 2016}

def code(s, width=6):
    s = s.astype('string').str.strip().str.replace(r'\.0$', '', regex=True)
    return s.where(s.str.fullmatch(r'\d{1,6}', na=False)).str.zfill(width)

def normalize(frame):
    d = frame.copy()
    d['stock_code'] = code(d['stock_code'])
    if 'report_date' in d:
        dates = pd.to_datetime(d['report_date'], errors='coerce')
        if dates.isna().any():
            raise ValueError('Invalid report_date: repair at source before analysis')
        if not (dates.dt.strftime('%m-%d') == '12-31').all():
            raise ValueError('Non-annual records found; do not mix quarterly and annual data')
        if 'year' in d and not pd.to_numeric(d['year'], errors='coerce').eq(dates.dt.year).all():
            raise ValueError('year disagrees with report_date')
        d['year'] = dates.dt.year
    d['year'] = pd.to_numeric(d['year'], errors='coerce')
    if d[KEY].isna().any().any() or not d['year'].eq(d['year'].round()).all():
        raise ValueError('Invalid firm/year key')
    d['year'] = d['year'].astype(int)
    for c in ['province_code', 'city_code']:
        if c in d:
            d[c] = code(d[c])
    for c in FLAGS + OUTCOMES + [x for x in CONTROLS if x != 'ln_total_assets'] + ['total_assets', 'carbon_intensity_base', 'carbon_intensity_base_w', 'carbon_intensity_base_z']:
        if c in d:
            old = d[c]
            d[c] = pd.to_numeric(old, errors='coerce').replace([np.inf, -np.inf], np.nan)
            if (old.notna() & d[c].isna()).any():
                warnings.warn(f'{c}: invalid numeric entries set missing; inspect source')
    return d

def collapse_consistent(d, out):
    """One firm-year; never select a convenient duplicate or average conflicts.

    A unique observed value can fill missing duplicate copies; >=2 distinct values
    cause that FIELD to be missing. Financial fields survive corrupt flag joins.
    """
    out = Path(out); out.mkdir(parents=True, exist_ok=True)
    g = d.groupby(KEY, sort=True, dropna=False)
    counts = g.size().rename('source_rows')
    nuniq = g.nunique(dropna=True)
    rows = []
    for c in nuniq.columns:
        bad = nuniq.index[nuniq[c] > 1]
        if len(bad):
            s = d.set_index(KEY)[c]
            vals = s.loc[s.index.isin(bad)].groupby(level=KEY).agg(lambda x: json.dumps(sorted(set(map(str, x.dropna()))), ensure_ascii=False))
            for idx, values in vals.items():
                rows.append(dict(stock_code=idx[0], year=idx[1], field=c, observed_values=values))
    pd.DataFrame(rows, columns=KEY+['field', 'observed_values']).to_csv(out/'duplicate_conflicts.csv', index=False)
    a = g.first()
    a = a.mask(nuniq > 1)
    a['source_rows'] = counts
    a = a.reset_index()
    counts.reset_index().to_csv(out/'duplicate_multiplicity.csv', index=False)
    pd.DataFrame({'field': nuniq.columns, 'conflict_firm_years': (nuniq > 1).sum().values}).to_csv(out/'conflict_summary.csv', index=False)
    # Predicted sentiment labels are NOMINAL. Existing independently computed modes
    # are inconsistent; reconstruct only from the surviving, unambiguous class.
    if 'pred_class' in a:
        valid = a['pred_class'].isin([0, 1, 2])
        mapped = a['pred_class'].where(valid).map({0: 2, 1: 0, 2: 1})
        if 'pred_Nbs' in a:
            mismatch = a['pred_Nbs'].notna() & mapped.notna() & a['pred_Nbs'].ne(mapped)
            a.loc[mismatch, KEY+['pred_class', 'pred_Nbs']].to_csv(out/'class_mapping_mismatches.csv', index=False)
            a['pred_Nbs_original'] = a['pred_Nbs']
        a['pred_Nbs'] = mapped
        a['negative_class'] = a['pred_class'].eq(0).astype(float).where(valid)
        a['nonneutral_class'] = a['pred_class'].ne(1).astype(float).where(valid)
    # Check, rather than silently overwrite, the documented clipped outcome.
    if {'Nbs_raw', 'Nbs_dminus'} <= set(a):
        both = a[['Nbs_raw', 'Nbs_dminus']].notna().all(axis=1)
        mismatch = both & ~np.isclose(a['Nbs_raw'].clip(lower=0), a['Nbs_dminus'], atol=1e-8, equal_nan=True)
        a.loc[mismatch, KEY+['Nbs_raw', 'Nbs_dminus']].to_csv(out/'nbs_definition_mismatches.csv', index=False)
        if mismatch.any():
            a.loc[mismatch, ['Nbs_raw', 'Nbs_dminus']] = np.nan
    assert not a.duplicated(KEY).any()
    return a

def aggregate_predictions(predict):
    """Replacement for original merged_finance cell 4-7.

    Every row must represent one valid, nonduplicated text unit upstream. Mode ties
    remain missing. Averaged probabilities are separate continuous outcomes.
    """
    p = predict.rename(columns={'负向概率': 'negative', '中性概率': 'neutral', '正向概率': 'positive', '预测分类': 'pred_class'}).copy()
    parts = p['file_name'].astype('string').str.extract(r'^(\d{1,6})-(\d{4})$')
    if parts.isna().any().any():
        raise ValueError('file_name must be firm-year; inspect malformed names')
    p['stock_code'] = code(parts[0]); p['year'] = parts[1].astype(int)
    for c in ['negative', 'neutral', 'positive', 'pred_class']:
        p[c] = pd.to_numeric(p[c], errors='coerce')
    probs = p[['negative', 'neutral', 'positive']]
    if not (probs.notna().all(axis=1) & probs.ge(0).all(axis=1) & probs.le(1).all(axis=1) & np.isclose(probs.sum(axis=1), 1, atol=1e-4) & p['pred_class'].isin([0,1,2])).all():
        raise ValueError('Invalid probabilities/classes: resolve upstream')
    def unique_mode(s):
        modes = s.mode()
        return modes.iloc[0] if len(modes) == 1 else np.nan
    r = p.groupby(KEY, as_index=False).agg(negative=('negative', 'mean'), neutral=('neutral', 'mean'), positive=('positive', 'mean'), pred_class=('pred_class', unique_mode), n_text_units=('pred_class', 'size'), negative_share=('pred_class', lambda x: x.eq(0).mean()))
    r['pred_Nbs'] = r['pred_class'].map({0:2, 1:0, 2:1})
    return r

def safe_annual_merge(finance, nbs, predictions):
    """Normalize all keys BEFORE merge; refuse duplicate keys on every source.

    Finance needs source-level deduplication using report type/date and original
    flag-table keys. Do not collapse true revisions without a documented rule.
    """
    f = normalize(finance)
    tables = [f]
    for source in [nbs, predictions]:
        s = source.copy(); s['stock_code'] = code(s['stock_code'])
        years = pd.to_numeric(s['year'], errors='raise')
        if years.isna().any() or not years.eq(years.round()).all():
            raise ValueError('Invalid year in merge source')
        s['year'] = years.astype(int)
        tables.append(s)
    for name, s in zip(['finance','nbs','predictions'], tables):
        if s[KEY].isna().any().any() or s.duplicated(KEY).any():
            raise ValueError(f'{name}: keys must be complete and unique before merge')
    r = tables[0]
    for name, s in zip(['nbs', 'prediction'], tables[1:]):
        r = r.merge(s, on=KEY, how='left', validate='one_to_one', indicator=f'{name}_merge')
    return r

def rebuild_nbs_from_validated_text(predict, inventory, same_nbs_text_universe=False):
    """Optional SOURCE repair, not executed on the merged CSV.

    inventory: file_name, processing_success, expected_text_units. An external
    inventory is required to distinguish a genuine neutral-only zero from a
    missing/failed document. Caller must confirm the original NbS text universe.
    """
    if not same_nbs_text_universe:
        raise ValueError('Confirm these are the SAME NbS-relevant text units before rebuilding')
    p=predict.rename(columns={'负向概率':'negative','中性概率':'neutral','正向概率':'positive','预测分类':'pred_class'}).copy()
    # Validate probabilities, labels and filename keys using shared logic.
    aggregate_predictions(p)
    for c in ['negative','neutral','positive','pred_class']:
        p[c]=pd.to_numeric(p[c],errors='raise')
    inv=inventory.copy()
    if inv.file_name.duplicated().any():raise ValueError('Duplicate document inventory')
    if not inv.processing_success.isin([True,False]).all():raise ValueError('processing_success must be Boolean')
    counts=p.groupby('file_name').size()
    inv['scored_text_units']=inv.file_name.map(counts).fillna(0)
    valid=inv.processing_success.eq(True)&inv.expected_text_units.gt(0)&inv.expected_text_units.eq(inv.scored_text_units)
    inv=inv.loc[valid].set_index('file_name')
    neg=p.loc[p.pred_class.eq(0)].groupby('file_name').negative.max()
    pos=p.loc[p.pred_class.eq(2)].groupby('file_name').positive.mean()
    # Conditional absence of one class is zero ONLY after full-document success.
    inv['neg_max']=neg.reindex(inv.index).fillna(0)
    inv['pos_mean']=pos.reindex(inv.index).fillna(0)
    inv['Nbs_raw']=inv.neg_max-inv.pos_mean
    inv['Nbs_dminus']=inv.Nbs_raw.clip(lower=0)
    parts=inv.index.to_series().str.extract(r'^(\d{1,6})-(\d{4})$')
    inv['stock_code']=code(parts[0]);inv['year']=parts[1].astype(int)
    return inv.reset_index()[KEY+['Nbs_raw','Nbs_dminus','scored_text_units']]

def prepare(panel, out, full_year=False):
    out = Path(out)
    d = panel.copy()
    flow = []
    def record(label):
        flow.append(dict(step=label, N=len(d), firms=d['stock_code'].nunique()))
    record('unique firm-years; no flag filtering')
    d = d[d.year.between(2009, 2020)].copy(); record('2009-2020; national ETS excluded')
    d = d[d.stock_code.str.match(r'^(60|68|00|30)', na=False)].copy(); record('Shanghai/Shenzhen A-share code universe')
    if 'industry_code' not in d:
        raise ValueError('Missing industry_code')
    d['industry_code'] = d['industry_code'].astype('string').str.strip()
    d = d[d.industry_code.notna() & ~d.industry_code.str.startswith('J', na=False)].copy(); record('known nonfinancial industry; N78 retained')
    # Assignment is frozen to the last jointly observed PRE-POLICY location.
    # No policy-post location is backfilled into the preperiod.
    loc = d.loc[d.year.le(2012)].dropna(subset=['province_code', 'city_code']).sort_values(KEY)
    loc = loc.groupby('stock_code', as_index=False).tail(1)[['stock_code','province_code','city_code']]
    loc = loc.rename(columns={'province_code':'province_base', 'city_code':'city_base'})
    d = d.merge(loc, on='stock_code', how='left', validate='many_to_one')
    d = d.dropna(subset=['province_base', 'city_base']).copy(); record('pre-2013 location available; no post-policy backfill')
    d['location_changed'] = ((d.province_code.notna() & d.province_code.ne(d.province_base)) | (d.city_code.notna() & d.city_code.ne(d.city_base))).fillna(False)
    d['g'] = d.province_base.map(START)
    d.loc[d.city_base.eq('440300'), 'g'] = 2013
    d['policy_launch_year'] = d['g']
    d['analysis_full_year'] = bool(full_year)
    if full_year:
        d['g'] = d['g'] + 1
        # Launch-year outcomes are already partly treated: NEVER relabel them as
        # untreated simply by shifting the first fully exposed year forward.
        d = d[~(d.policy_launch_year.notna() & d.year.eq(d.policy_launch_year))].copy()
        record('full-year sensitivity: omit partially treated launch years')
    d['ETS_rt'] = (d.g.notna() & d.year.ge(d.g)).astype(int)
    # Recompute on ONE VALUE PER FIRM, without row-frequency weighting.
    base = 'carbon_intensity_base' if 'carbon_intensity_base' in d else 'carbon_intensity_base_w'
    if base not in d:
        raise ValueError('Missing pre-policy carbon intensity')
    v = d.groupby('stock_code')[base].nunique()
    bad = v.index[v.gt(1)]
    d.loc[d.stock_code.isin(bad), base] = np.nan
    firms = d.groupby('stock_code')[base].first().dropna()
    firms = firms[firms.ge(0)]
    if len(firms) < 2:
        raise ValueError('Insufficient reliable baseline carbon values')
    lo, hi = firms.quantile([.01,.99]); w = firms.clip(lo,hi)
    sd = w.std()
    if not np.isfinite(sd) or sd <= 0:
        raise ValueError('No baseline carbon variation')
    z = (w-w.mean())/sd
    d['carbon_z'] = d.stock_code.map(z)
    (out/'carbon_scaling.json').write_text(json.dumps(dict(source=base, firms=len(firms), lower=float(lo), upper=float(hi), mean=float(w.mean()), sd=float(sd), inconsistent_firms=len(bad)), indent=2))
    d['ETS_x_Carbon'] = d.ETS_rt*d.carbon_z
    d['province_year'] = d.province_base+'_'+d.year.astype(str)
    d['ind_year'] = d.industry_code+'_'+d.year.astype(str)
    if 'total_assets' in d:
        d['ln_total_assets'] = np.log(d.total_assets.where(d.total_assets.gt(0)))
    present = [c for c in CONTROLS if c in d]
    # No RD missing=zero; no positive-leverage restriction.
    lag = d[KEY+present].copy(); lag['year'] += 1
    lag = lag.rename(columns={c:c+'_lag1' for c in present})
    d = d.merge(lag, on=KEY, how='left', validate='one_to_one')
    pd.DataFrame(flow).to_csv(out/'sample_flow.csv', index=False)
    return d

def support_table(d, outcomes, out):
    rows=[]
    for y in outcomes:
        for g in sorted(d.g.dropna().unique()):
            a=d[d.g.eq(g) & d.carbon_z.notna()].copy()
            a['pre']=a.year.between(g-3,g-1) & a[y].notna()
            a['post']=a.year.between(g,g+3) & a[y].notna()
            s=a.groupby('stock_code')[['pre','post']].sum()
            rows.append(dict(outcome=y, cohort=int(g), firms=len(s), both_sides=int((s.pre.ge(1)&s.post.ge(1)).sum()), two_each_side=int((s.pre.ge(2)&s.post.ge(2)).sum()), pre_observations=int(s.pre.sum()), post_observations=int(s.post.sum())))
    pd.DataFrame(rows).to_csv(Path(out)/'pre_post_support.csv',index=False)
    d.assign(**{y:d[y].notna().astype(int) for y in outcomes}).groupby(['year','province_base'],as_index=False)[outcomes].agg(['sum','count']).to_csv(Path(out)/'outcome_coverage.csv')

def cohort_sample(d, y, g, min_each=2, horizon='window3'):
    """Cohort g vs never/later treated through end of fixed window.

    Symmetric calendar window -3..+3; default minimum two observed years on
    EACH side for BOTH treated/control firms. Not an outcome-value filter.
    Returns support-selected sample; cannot manufacture missing observations.
    """
    end = min(int(g)+3, 2020) if horizon=='window3' else 2020
    begin = int(g)-3 if horizon=='window3' else 2009
    a = d[d.year.between(begin, end) & (d.g.eq(g) | d.g.isna() | d.g.gt(end))].copy()
    a = a.dropna(subset=[y,'carbon_z','province_year','ind_year'])
    a['post'] = a.year.ge(g).astype(int)
    a['treated'] = a.g.eq(g).astype(int)
    n=a.groupby(['stock_code','post']).size().unstack(fill_value=0).reindex(columns=[0,1], fill_value=0)
    good=n.index[n[0].ge(min_each)&n[1].ge(min_each)]
    a=a[a.stock_code.isin(good)].copy()
    a['exposure_post']=a.treated*a.post*a.carbon_z
    return a

def prune_singletons(d, fes=('stock_code','province_year','ind_year')):
    d=d.copy()
    while len(d):
        keep=pd.Series(True,index=d.index)
        for c in fes:
            keep &= d.groupby(c)[c].transform('size').gt(1)
        if keep.all():break
        d=d[keep].copy()
    return d

def prune_analysis_support(d):
    """Both-side support and FE singleton removal must hold simultaneously."""
    d=d.copy()
    while len(d):
        n_before=len(d)
        d=prune_singletons(d)
        n=d.groupby(['stock_code','post']).size().unstack(fill_value=0).reindex(columns=[0,1],fill_value=0)
        keep=n.index[n[0].ge(2)&n[1].ge(2)]
        d=d[d.stock_code.isin(keep)].copy()
        if len(d)==n_before:break
    return d

def fit_all(d, outcomes, out):
    import pyfixest as pf
    out=Path(out); rows=[]; support=[]
    # Retire only this runner's per-model outputs so skipped models cannot leave
    # an older successful event/sample file looking like a current result.
    for y in outcomes:
        for prefix in ['event_'+y+'_', 'sample_'+y+'_']:
            for old in out.glob(prefix+'*'):
                if old.is_file() and old.suffix in ['.csv','.txt']:
                    old.unlink()
    # Prespecified specifications; report all, never select by p-value.
    for y, horizon in [(y,h) for y in outcomes for h in ['window3','all_available']]:
        for g in sorted(d.g.dropna().unique()):
            a=cohort_sample(d,y,g,horizon=horizon)
            for spec in ['primary','stable_location','verified_flags_zero','lag_controls_common_sample','no_controls_common_sample']:
                b=a.copy(); extras=[]
                if spec=='stable_location':
                    movers=d.groupby('stock_code').location_changed.any()
                    b=b[~b.stock_code.isin(movers.index[movers])].copy()
                if spec=='verified_flags_zero':
                    if not all(c in b for c in FLAGS):
                        rows.append(dict(outcome=y,horizon=horizon,cohort=int(g),spec=spec,status='unrun: missing flag fields'));continue
                    # Pre-policy flags only: avoids conditioning inclusion on a
                    # potentially policy-affected contemporaneous outcome.
                    pre=d[d.year.le(2012)]
                    ok=pre.groupby('stock_code')[FLAGS].agg(lambda s: s.notna().all() and s.eq(0).all()).all(axis=1)
                    b=b[b.stock_code.isin(ok.index[ok])].copy()
                if 'common_sample' in spec:
                    lagvars=[c+'_lag1' for c in CONTROLS]
                    if not all(c in b for c in lagvars):
                        rows.append(dict(outcome=y,horizon=horizon,cohort=int(g),spec=spec,status='unrun: missing lag control fields'));continue
                    b=b.dropna(subset=lagvars).copy()
                    if spec=='lag_controls_common_sample':extras=lagvars
                # Recheck bilateral support after EVERY specification filter.
                n=b.groupby(['stock_code','post']).size().unstack(fill_value=0).reindex(columns=[0,1],fill_value=0)
                keep=n.index[n[0].ge(2)&n[1].ge(2)]
                b=b[b.stock_code.isin(keep)].copy()
                N_input=len(b)
                b=prune_analysis_support(b)
                meta=dict(outcome=y,horizon=horizon,cohort=int(g),spec=spec,N_input=N_input,N_after_singletons=len(b),treated_firms=b.loc[b.treated.eq(1),'stock_code'].nunique(),control_firms=b.loc[b.treated.eq(0),'stock_code'].nunique(),clusters_input=b.province_base.nunique(),treated_clusters=b.loc[b.treated.eq(1),'province_base'].nunique())
                if min(meta['treated_firms'],meta['control_firms'])<2 or meta['clusters_input']<6:
                    rows.append(dict(**meta,status='unrun: insufficient bilateral/cluster support'));continue
                f=y+' ~ exposure_post + i(year, carbon_z)'+(' + '+' + '.join(extras) if extras else '')+' | stock_code + province_year + ind_year'
                try:
                    m=pf.feols(f,data=b,vcov={'CRV1':'province_base'},demeaner_backend='numba')
                    if 'exposure_post' not in m.coef().index:
                        rows.append(dict(**meta,status='unidentified: interaction absorbed'));continue
                    if not np.isfinite(float(m.se()['exposure_post'])) or float(m.se()['exposure_post'])<=0 or np.mean(np.asarray(m.resid())**2)<1e-16:
                        rows.append(dict(**meta,status='unidentified: saturated model or invalid variance'));continue
                    ci=m.confint().loc['exposure_post']
                    # Actual N after singleton deletion, not len(input).
                    rows.append(dict(**meta,status='estimated; CRV1 exploratory, few treated provinces',inference_reliable=False,N_effective=int(m._N),coef=float(m.coef()['exposure_post']),se=float(m.se()['exposure_post']),p=float(m.pvalue()['exposure_post']),ci_low=float(ci.iloc[0]),ci_high=float(ci.iloc[1]),formula=f))
                    b.assign(model_outcome=y,model_cohort=int(g),model_spec=spec)[KEY+['treated','post','province_base','model_outcome','model_cohort','model_spec']].to_csv(out/f'sample_{y}_{int(g)}_{horizon}_{spec}.csv',index=False)
                    # Cohort-specific leads/lags; reference -1. No already-treated controls.
                    if spec=='primary' and horizon=='window3':
                        e=b.copy(); terms=[]
                        full=bool(e['analysis_full_year'].iloc[0]) if 'analysis_full_year' in e else False
                        ref=-2 if full else -1
                        if not (e.treated.eq(1)&e.year.sub(g).eq(ref)).any():
                            (out/f'event_{y}_{int(g)}_failure.txt').write_text('Unrun: no treated observations in the untreated reference year')
                            continue
                        # -1 is the omitted launch year under full-year timing;
                        # use last genuinely untreated year (-2) as reference.
                        event_k=[-3,0,1,2,3] if full else [-3,-2,0,1,2,3]
                        for k in event_k:
                            name='event_'+('m'+str(-k) if k<0 else 'p'+str(k))
                            e[name]=e.treated*e.year.sub(g).eq(k).astype(int)*e.carbon_z
                            terms.append(name)
                        try:
                            em=pf.feols(y+' ~ '+' + '.join(terms)+' + i(year, carbon_z) | stock_code + province_year + ind_year',data=e,vcov={'CRV1':'province_base'},demeaner_backend='numba')
                            event=em.tidy().reset_index()
                            event.to_csv(out/f'event_{y}_{int(g)}.csv',index=False)
                        except (ValueError,RuntimeError,ArithmeticError) as exc:
                            (out/f'event_{y}_{int(g)}_failure.txt').write_text(repr(exc))
                except (ValueError,RuntimeError,ArithmeticError) as exc:
                    rows.append(dict(**meta,status='failed: '+repr(exc)))
    result=pd.DataFrame(rows)
    result.to_csv(out/'cohort_results.csv',index=False)
    return result

def sample_comparison(raw, d, out):
    """Replicate v3 cleaning for a same-calendar descriptive comparison only."""
    old=normalize(raw)
    old=old[old.year.between(2009,2022)].copy()
    for c in FLAGS:
        old=old[old[c].ne(1)|old[c].isna()].copy()
    old=old[old.stock_code.str.match(r'^(60|68|00|30)',na=False)].copy()
    industry=old.industry_code.astype('string')
    old=old[~industry.str.startswith('J',na=False)&~industry.isin(['N78'])].copy()
    old['rd_ratio']=old.rd_ratio.fillna(0)
    for c in ['total_assets','leverage','roa','cashflow','tobin_q','rd_ratio','fixed_assets']:
        lo,hi=old[c].quantile([.01,.99]);old[c]=old[c].clip(lo,hi)
    old=old[(old.total_assets>0)&(old.leverage>0)].copy()
    old['ln_total_assets']=np.log(old.total_assets)
    old=old.dropna(subset=KEY+['province_code','city_code','industry_code','carbon_intensity_base_w']+CONTROLS)
    rows=[]
    for label,b in [('v3_original_2009_2022',old),('v3_restricted_2009_2020',old[old.year.le(2020)]),('v4_2009_2020_pre_location',d),('v4_with_baseline_carbon',d[d.carbon_z.notna()])]:
        rows.append(dict(sample=label,N=len(b),firms=b.stock_code.nunique(),Nbs_raw_observed=b.Nbs_raw.notna().sum(),negative_observed=b.negative.notna().sum()))
    result=pd.DataFrame(rows)
    result.to_csv(Path(out)/'sample_comparison.csv',index=False)
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--out',default='result_v4');ap.add_argument('--full-year',action='store_true');ap.add_argument('--audit-only',action='store_true')
    args=ap.parse_args();out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    raw=pd.read_csv(args.input,dtype={'stock_code':'string'},encoding='utf-8-sig')
    panel=collapse_consistent(normalize(raw),out)
    panel.to_csv(out/'repaired_unique_panel.csv',index=False)
    d=prepare(panel,out,full_year=args.full_year)
    d.to_csv(out/'analysis_panel.csv',index=False)
    # Nbs_raw is the primary outcome. Others are distinct, secondary endpoints.
    outcomes=[c for c in ['Nbs_raw','Nbs_dminus','negative','negative_class','nonneutral_class'] if c in d]
    support_table(d,outcomes,out)
    if not args.full_year:
        sample_comparison(raw,d,out)
    if not args.audit_only:
        fit_all(d,outcomes,out)
    (out/'run_metadata.json').write_text(json.dumps(dict(input=str(Path(args.input).resolve()),input_sha256=hashlib.sha256(Path(args.input).read_bytes()).hexdigest(),raw_rows=len(raw),unique_rows=len(panel),analysis_rows=len(d),end_year=2020,full_year=args.full_year,audit_only=args.audit_only,policy_calendar=START,policy_external_verification='pending: official/ICAP HTTPS requests rejected by proxy 403',primary_outcome='Nbs_raw',interpretation='regional assignment; exposure-gradient change, not firm compliance ATT',executed=True),ensure_ascii=False,indent=2))
    print('Completed:',out.resolve())

if __name__=='__main__': main()
