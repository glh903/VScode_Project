import tempfile
import unittest
from pathlib import Path
import pandas as pd
import numpy as np
from repair_analysis import normalize, collapse_consistent, aggregate_predictions, safe_annual_merge, cohort_sample, rebuild_nbs_from_validated_text, prepare, prune_analysis_support

class RepairTests(unittest.TestCase):
    def test_conflicts_are_not_resolved_by_row_selection(self):
        d=pd.DataFrame(dict(stock_code=['1','1','2'],year=[2012]*3,total_assets=[10,10,20],is_st=[0,1,0],Nbs_raw=[.2,.2,np.nan],Nbs_dminus=[.2,.2,np.nan],pred_class=[0,0,1],pred_Nbs=[0,0,0]))
        with tempfile.TemporaryDirectory() as tmp:
            a=collapse_consistent(normalize(d),tmp).set_index('stock_code')
            self.assertEqual(len(a),2)
            self.assertEqual(a.loc['000001','total_assets'],10)
            self.assertTrue(pd.isna(a.loc['000001','is_st']))
            self.assertEqual(a.loc['000001','pred_Nbs'],2)
            self.assertTrue(pd.isna(a.loc['000002','Nbs_raw']))
            conflicts=pd.read_csv(Path(tmp)/'duplicate_conflicts.csv')
            self.assertEqual(conflicts.field.tolist(),['is_st'])

    def test_modal_ties_missing_and_codes_consistent(self):
        p=pd.DataFrame(dict(file_name=['1-2012']*2+['2-2012'],negative=[.9,.1,.1],neutral=[.05,.1,.8],positive=[.05,.8,.1],pred_class=[0,2,1]))
        a=aggregate_predictions(p)
        self.assertTrue(pd.isna(a.iloc[0].pred_class))
        self.assertTrue(pd.isna(a.iloc[0].pred_Nbs))
        self.assertEqual(a.iloc[1].pred_Nbs,0)
        self.assertAlmostEqual(a.iloc[0].negative_share,.5)

    def test_merge_normalizes_keys_and_rejects_cartesian_join(self):
        f=pd.DataFrame(dict(stock_code=['1'],report_date=['2012-12-31']))
        n=pd.DataFrame(dict(stock_code=['000001'],year=[2012],Nbs_raw=[.3]))
        p=pd.DataFrame(dict(stock_code=['1.0'],year=[2012],negative=[.4]))
        self.assertEqual(safe_annual_merge(f,n,p).iloc[0].Nbs_raw,.3)
        with self.assertRaises(ValueError):safe_annual_merge(pd.concat([f,f]),n,p)

    def test_later_treated_control_never_enters_after_its_treatment(self):
        rows=[]
        for firm,g in [('a',2013),('b',2014),('c',2016),('d',np.nan),('e',2017)]:
            for year in range(2010,2017):
                rows.append(dict(stock_code=firm,year=year,g=g,y=1.,carbon_z=1.,province_year=str(year),ind_year=str(year)))
        a=cohort_sample(pd.DataFrame(rows),'y',2013)
        self.assertEqual(set(a.stock_code),{'a','d','e'})
        self.assertTrue(a.groupby('stock_code').post.nunique().eq(2).all())

    def test_only_verified_neutral_documents_become_zero(self):
        p=pd.DataFrame(dict(file_name=['1-2012','2-2012'],negative=[.1,.1],neutral=[.8,.8],positive=[.1,.1],pred_class=[1,1]))
        inv=pd.DataFrame(dict(file_name=['1-2012','2-2012','3-2012'],processing_success=[True,False,True],expected_text_units=[1,1,2]))
        with self.assertRaises(ValueError):rebuild_nbs_from_validated_text(p,inv)
        a=rebuild_nbs_from_validated_text(p,inv,same_nbs_text_universe=True)
        self.assertEqual(a.stock_code.tolist(),['000001'])
        self.assertEqual(a.iloc[0].Nbs_raw,0)

    def test_full_year_never_calls_launch_year_untreated(self):
        rows=[]
        for firm,carbon in [('000001',1.),('000002',2.),('000003',3.)]:
            for year in range(2009,2021):
                rows.append(dict(stock_code=firm,year=year,province_code='440000',city_code='440100',industry_code='C26',carbon_intensity_base=carbon))
        with tempfile.TemporaryDirectory() as tmp:
            a=prepare(pd.DataFrame(rows),tmp,full_year=True)
            self.assertFalse(a.year.eq(2013).any())
            self.assertTrue(a.loc[a.year.eq(2012),'ETS_rt'].eq(0).all())
            self.assertTrue(a.loc[a.year.eq(2014),'ETS_rt'].eq(1).all())

    def test_bilateral_support_rechecked_after_singleton_removal(self):
        rows=[]
        for firm in ['a','b']:
            for year in [2010,2011,2012,2013]:
                rows.append(dict(stock_code=firm,post=int(year>=2012),province_year=str(year),ind_year=(firm if year==2010 else 'common')+str(year)))
        # 2010 is singleton by industry-year: each firm then has only ONE preyear.
        self.assertTrue(prune_analysis_support(pd.DataFrame(rows)).empty)

if __name__=='__main__':unittest.main()
